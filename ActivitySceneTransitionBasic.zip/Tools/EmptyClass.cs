﻿using System;

namespace ActivitySceneTransitionBasic
{
	public class EmptyClass
	{
		public EmptyClass ()
		{
		}
	}
}

